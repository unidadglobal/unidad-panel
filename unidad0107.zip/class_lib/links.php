<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<!-- Main CSS -->
<link rel="stylesheet" href="./css/main.css">
<!-- Ionicons -->
<link rel="stylesheet" href="dist/css/ionicons.css">
<link rel="stylesheet" href="css/bootstrap4.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/toastr.css">
<link rel="stylesheet" type="text/css" href="css/datatables.min.css"/>
<link href="css/roboto.css" type="text/css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="Croppie/cropper.min.css" />
<link rel="stylesheet" href="./css/loading.css">
