<script src="./js/jquery-3.6.0.min.js" type="text/javascript"></script>
<script src="./js/jquery-ui.min.js" type="text/javascript"></script>
<script src="./js/bootstrap.bundle.min.js"></script>
<script src="./js/toastr.min.js"></script>
<script src="Croppie/cropper.min.js"></script>
<script src="Croppie/jquery-cropper.min.js"></script>
<script type="text/javascript" src="./js/datatables.min.js"></script>

<script src="https://www.gstatic.com/firebasejs/8.0.1/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.0.1/firebase-analytics.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.0.1/firebase-auth.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.0.1/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.0.1/firebase-storage.js"></script>
<script>
  const firebaseConfig = {
   apiKey: "AIzaSyB2IImGNZIVFs8hIk7wXtfScvjsoO57-sQ",
   authDomain: "crisplay-tv.firebaseapp.com",
   projectId: "crisplay-tv",
   storageBucket: "crisplay-tv.appspot.com",
   messagingSenderId: "689980443424",
   appId: "1:689980443424:web:0f602d05da38cf3e746545",
   measurementId: "G-PK506SBXYS"
 };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  const auth = firebase.auth();
</script>

<!-- Sweet Alert 2-->
<script src="./js/sweetalert.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.js"></script>
<!-- Script main-->
<script src="./js/main.js"></script>