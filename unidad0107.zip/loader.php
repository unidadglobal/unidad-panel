<div class="loading-wrapper">
          <div class="load-3 mt-4 ml-4">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
          </div>
</div>