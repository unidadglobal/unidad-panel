<footer class="main-footer">
  <!-- To the right -->
  <div class="pull-right hidden-xs">
    <small>Desarrollado por <a href='https://instagram.com/alanampo' target="_blank">Alan Ampo</a></small>
  </div>
  <!-- Default to the left -->
  <span id="copyright"></span>
</footer>
<script>
      const paragraph = `
        <strong><a href='https://facebook.com/' target="_blank">&copy; ${new Date().getFullYear()} Carlos Franco Pilar</a></strong>
      `;

      document.getElementById('copyright').innerHTML = paragraph;
    </script>
